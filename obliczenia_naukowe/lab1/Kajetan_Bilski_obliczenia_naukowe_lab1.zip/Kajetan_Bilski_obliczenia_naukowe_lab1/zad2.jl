#Kajetan Bilski
println(3*(Float16(4.)/3-1)-1)
println(3*(4f0/3-1)-1)
println(3*(4e0/3-1)-1)
