//Kajetan Bilski
#include<stdio.h>
#include<float.h>
int main(){
printf("%e\n",FLT_EPSILON);
printf("%le\n",DBL_EPSILON);
return 0;
}
