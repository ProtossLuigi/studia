Autor: Kajetan Bilski 244942

test 6-mod-mult.imp nie dzia�a na maszynie bez cln

kompilowane aktualnymi wersjami g++, flex i bison na ubuntu