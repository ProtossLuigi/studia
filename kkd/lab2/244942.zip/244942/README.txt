lista 2 zadanie na 5
u�ycie:
python encode.py plik_do_skompresowania plik_skompresowany
python decode.py plik_do_zdekompresowania plik_zdekompresowany