lista 3 zadanie na 5
u�ycie:
python encode.py plik_do_skompresowaania plik_skompresowany metoda
python decode.py plik_do_zdekompresowaania plik_zdekompresowany metoda

gdzie metoda jest opcjonalna:
-gamma
-delta
-fib
domy�lne kodowanie to omega